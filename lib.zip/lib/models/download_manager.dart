import 'pdf_file_model.dart';

class DownloadManager {
  static List<PdfFileModel> downloadedPdfs = [];
}