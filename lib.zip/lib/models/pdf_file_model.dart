class PdfFileModel {
  final String assetPath;
  final String name;

  PdfFileModel({required this.assetPath, required this.name});
}